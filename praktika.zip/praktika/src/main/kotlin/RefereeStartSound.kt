object RefereeSound {
    var startSound = false
    val distance = 100
    fun raceStart(){
        println("Судья разрешил забег ")
        startSound = true
    }
    fun raceFinish(){
        println("Судья завершил забег")
        startSound = false
    }

}