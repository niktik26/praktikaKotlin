import kotlin.math.max
import kotlin.random.Random

class People(val nation: String, val firstName: String, var growth: Int = 100, ) {
    constructor(descriptor: Pair<String, String>, growth : Int) : this(
        nation = descriptor.first,
        firstName = descriptor.second,
        growth = growth
    ){
//        println("Вторичный конструктор")
    }

    init {
//        println("people init")
    }
    //Скорость шага, скорость остановки
    var runningSpeed = 0.0
    private set
     var energy = 100.0

    init {
//        println("second init")
    }
    //Скорость шага, скорость остановки
    fun accelerate(speed : Double){
        val needEnergy = speed * 3
        if (energy > needEnergy){
            runningSpeed += speed
            useEnergy(speed * 5)
        }
        else println("Спортсмен устал")

    }
    fun decelerate(speed : Double){
        runningSpeed = maxOf(0.0, runningSpeed - speed)
//        val finalSpeed = runningSpeed - speed
//        runningSpeed = if (finalSpeed < 0) 0.0 else finalSpeed
    }
    private fun useEnergy(energy:Double){
        this.energy -= energy
    }
    // Увеличение роста
    fun growFat() {
        var fat = Random.nextInt(0,10)
        println("$firstName вырос $fat см")

    }
    companion object {
        const val timeRaceLose = 10
        fun getPeopleClass(length : Double) : String = when {
            length < 7 -> "1"
            length < 8 -> "2"
            length < 10 -> "3"
            else -> "Проигрыш"
        }
    }
}
