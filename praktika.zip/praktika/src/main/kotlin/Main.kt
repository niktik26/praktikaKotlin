import kotlin.random.Random

fun main() {

    val ron = People(descriptor = "USA" to "Ron", growth = 200)
    val karl = People(descriptor = "German" to "Karl", growth = 170)
    val elena = People(descriptor = "Russia" to "Elena", growth =  180)
    println("Расстояние забега - ${RefereeSound.distance}")

   println("Информация об участниках: ")
    println("Первый спортсмен - Имя - ${ron.firstName}, Страна - ${ron.nation} , Рост -  ${ron.growth}")
    println("Первый спортсмен - Имя - ${karl.firstName}, Страна - ${karl.nation}, Рост - ${karl.growth}")
    println("Первый спортсмен - Имя -  ${elena.firstName}, Страна - ${elena.nation}, Рост - ${elena.growth}")
    RefereeSound.raceStart()

    println("Скорость спортсмена Ron: ${ron.runningSpeed} км.ч")
    println("Энергия спортсмена Ron: ${ron.energy} %")

    println("Изначальная корость спортсмена Karl: ${karl.runningSpeed} км.ч")
    println("Запас энергии спортсмена Karl: ${karl.energy} %")

    println("Изначальная Скорость спортсмена Elena: ${elena.runningSpeed} км.ч")
    println("Запас Энергия спортсмена Elena: ${elena.energy} %")
    ron.accelerate(10.0)
    ron.decelerate(3.0)
    karl.accelerate(9.0)
    karl.decelerate(5.0)
    elena.accelerate(12.0)
    elena.decelerate(5.0)
    println("Скорость спортсмена на финише Ron: ${ron.runningSpeed} км.ч")
    println("Остаток энергии спортсмена Ron: ${ron.energy} %")

    println("Скорость спортсмена на финише Karl: ${karl.runningSpeed} км.ч")
    println("Остаток энергии спортсмена Karl: ${karl.energy} %")

    println("Скорость спортсмена на финише Elena: ${elena.runningSpeed} км.ч")
    println("Остаток энергии спортсмена Elena: ${elena.energy} %")
    RefereeSound.raceFinish()

    println("Время забега Ron: ${People.timeRaceLose}")
    val sportsmenTime1 = People.getPeopleClass(6.1)
    println(sportsmenTime1)
 println("Время забега Karl: ${People.timeRaceLose}")
 val sportsmenTime2 = People.getPeopleClass(9.1)
 println(sportsmenTime2)
 println("Время забега Elena: ${People.timeRaceLose}")
 val sportsmenTime3 = People.getPeopleClass(7.1)
 println(sportsmenTime3)
}
fun printInfo( people: People){
    println("Nation: ${people.nation} , firstName: ${people.firstName} , Growth: ${people.growth}   ")
}
